# RSA commands

# compile bn_sample.c
gcc bn_sample.c -lcrypto